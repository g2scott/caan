<?php 

	/**
	* 
	*/
	class Video
	{
		//public $id ;
		public $v_id ;
		public $name ;
		public $link ;
		public $thumbnail ;
		public $poster_frame ;
		public $sprout_id ;
		public $description ;
		public $type ;
		
	}






 ?>