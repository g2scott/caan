<?php

/**
 * The Facebook application ID that you used
 */
$config['fb_appid'] = '';

/**
 * The secret key associated to that application ID
 */
$config['fb_secret'] = '';

?>
