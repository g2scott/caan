    <div class="container">
        <hr>
        <footer>
            <div class="row">
            
                <div class="col-lg-12">
                <div class="pull-right" style="margin-top: 7px;">
                <div class="fb-like pull-right" data-href="http://www.caanapp.ca" data-width="20" data-layout="button_count" data-action="like" data-show-faces="true" data-share="true"></div>    
                </div>
 <a href="http://caanetwork.ca" class="pull-right text" style="text-decoration:none; margin-top: 7px;"><font color="#000000">� 2014 Canadian Amateur Athletes Network</font> </a>                   <!-- Twitter -->
 <!-- Facebook -->
<a href="https://www.facebook.com/CAANetwork" title="Share on Facebook" target="_blank" class="btn btn-facebook pull-right"><i class="fa fa-facebook"></i> Facebook</a>

                    	
                </div>
            </div>
        </footer>
    </div>

</body>

</html>
